package root.gui;

import root.app.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminGui extends JFrame {

    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField adminUser;
    private JPasswordField adminPass;
    private JPanel bottomPanel;
    private JPanel mainPanel;
    private JPanel userPanel;
    private JPanel passPanel;
    private JPanel buttonPanel;
    private JLabel adminTitle;
    private JLabel userLabel;
    private JLabel passLabel;

    public AdminGui(Main obj) {

        setTitle("HMS");
        adminTitle.setFont(new Font("Times New Roman",Font.BOLD,20));
        userLabel.setFont(new Font("Arial",Font.PLAIN,16));
        passLabel.setFont(new Font("Arial",Font.PLAIN,16));
        buttonOK.setFont(new Font("Arial",Font.PLAIN,14));
        buttonCancel.setFont(new Font("Arial",Font.PLAIN,14));
        setContentPane(contentPane);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });

        buttonCancel.addActionListener(actionEvent -> {
            dispose();
            new Entry(obj);
        });

        buttonOK.addActionListener(actionEvent -> {
            dispose();
            new DocAdd(obj);
        });


        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        pack();
        setSize(400,300);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new java.awt.Color(69, 94, 199, 226));
        mainPanel.setOpaque(false);
        userPanel.setOpaque(false);
        passPanel.setOpaque(false);
        buttonPanel.setOpaque(false);
        bottomPanel.setOpaque(false);
        setVisible(true);
    }

    private void onOK() {
        // add your code here
        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }
}
