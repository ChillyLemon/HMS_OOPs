package root.gui;

import root.app.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StaffInfo extends JFrame {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonBack;
    private JTextField staffID;
    private JLabel staffName;
    private JLabel staffGen;
    private JLabel staffDOB;
    private JLabel staffBG;
    private JLabel staffCN;
    private JLabel staffTitle;
    private JLabel staffidLabel;
    private JLabel nameLabel;
    private JLabel gLabel;
    private JLabel dobLabel;
    private JLabel bgLabel;
    private JLabel ctnLabel;
    private JPanel buttonPanel;
    private JPanel bottomPanel;
    private JPanel mainPanel;
    private JPanel idPanel;
    private JPanel namePanel;
    private JPanel gPanel;
    private JPanel dobPanel;
    private JPanel bgPanel;
    private JPanel ctnPanel;

    public StaffInfo(Main obj) {
        setTitle("HMS");
        staffTitle.setFont(new Font("Times New Roman",Font.BOLD,20));
        staffidLabel.setFont(new Font("Arial",Font.PLAIN,16));
        nameLabel.setFont(new Font("Arial",Font.PLAIN,16));
        dobLabel.setFont(new Font("Arial",Font.PLAIN,16));
        gLabel.setFont(new Font("Arial",Font.PLAIN,16));
        ctnLabel.setFont(new Font("Arial",Font.PLAIN,16));
        bgLabel.setFont(new Font("Arial",Font.PLAIN,16));
        buttonOK.setFont(new Font("Arial",Font.PLAIN,14));
        buttonBack.setFont(new Font("Arial",Font.PLAIN,14));
        setContentPane(contentPane);

        buttonOK.addActionListener(e -> onOK());

        buttonBack.addActionListener(e -> {
            dispose();
            new Entry(obj);
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        pack();
        setSize(500,400);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new java.awt.Color(69, 94, 199, 226));
        mainPanel.setOpaque(false);
        idPanel.setOpaque(false);
        namePanel.setOpaque(false);
        dobPanel.setOpaque(false);
        gPanel.setOpaque(false);
        ctnPanel.setOpaque(false);
        bgPanel.setOpaque(false);
        bottomPanel.setOpaque(false);
        buttonPanel.setOpaque(false);
        setVisible(true);
    }

    private void onOK() {
        // add your code here
        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }


}
