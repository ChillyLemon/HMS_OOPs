package root.gui;

import root.app.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DocInfo extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JLabel docName;
    private JLabel docG;
    private JLabel docDOB;
    private JLabel docCN;
    private JLabel docDpt;
    private JLabel docBG;
    private JLabel docTitle;
    private JLabel nameLabel;
    private JLabel gLabel;
    private JLabel dobLabel;
    private JLabel ctnLabel;
    private JLabel deptLabel;
    private JLabel bgLabel;
    private JPanel mainPanel;
    private JPanel bottomPanel;
    private JPanel namePanel;
    private JPanel gPanel;
    private JPanel dobPanel;
    private JPanel ctnPanel;
    private JPanel deptPanel;
    private JPanel bgPanel;

    public DocInfo(Main obj) {
        setTitle("HMS");
        docTitle.setFont(new Font("Times New Roman",Font.BOLD,20));
        nameLabel.setFont(new Font("Arial",Font.PLAIN,16));
        dobLabel.setFont(new Font("Arial",Font.PLAIN,16));
        gLabel.setFont(new Font("Arial",Font.PLAIN,16));
        ctnLabel.setFont(new Font("Arial",Font.PLAIN,16));
        bgLabel.setFont(new Font("Arial",Font.PLAIN,16));
        deptLabel.setFont(new Font("Arial",Font.PLAIN,16));
        buttonCancel.setFont(new Font("Arial",Font.PLAIN,14));
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        pack();
        setSize(600,400);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new java.awt.Color(69, 94, 199, 226));
        mainPanel.setOpaque(false);
        namePanel.setOpaque(false);
        dobPanel.setOpaque(false);
        gPanel.setOpaque(false);
        ctnPanel.setOpaque(false);
        bgPanel.setOpaque(false);
        deptPanel.setOpaque(false);
        bottomPanel.setOpaque(false);
        setVisible(true);
    }

    private void onOK() {
        // add your code here
        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }
}
